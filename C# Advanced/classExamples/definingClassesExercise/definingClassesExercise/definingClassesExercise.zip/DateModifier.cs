﻿using System;
using System.Collections.Generic;
using System.Text;

namespace definingClassesExercise
{
    class DateModifier
    {
       public static double GetData (DateTime dateTime1 , DateTime dateTime2)
        {
            //if (dateTime1 > dateTime2)
            //{
            //    return (dateTime1 - dateTime2).TotalDays;
            //}
            //if (dateTime2 > dateTime1)
            //    {
            //    return (dateTime2 - dateTime1).TotalDays;
            //}
            //return 0;

            double result = Math.Abs((dateTime1 - dateTime2).TotalDays);
            return result;
        }
    }
}
